//
//  GroupModel.swift
//  EnrichMyGroup
//
//  Created by Hiren Patel on 15/05/18.
//  Copyright © 2018 Hiren Patel. All rights reserved.
//

import UIKit

class GroupModel {

    var id: Int = 0
    var createdDt: String? = ""
    var title: String? = ""
    var groupId: Int = 0
    var groupName: String? = ""
    var leaderId: Int = 0
    var leaderName: String? = ""

    init() {

    }


}

